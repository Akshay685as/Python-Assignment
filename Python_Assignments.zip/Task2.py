# task2_greeting.py


first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# Concatenate full name
full_name = first_name + " " + last_name

# Display greeting
print(f"Hello, {full_name}! Welcome to Python programming ")
